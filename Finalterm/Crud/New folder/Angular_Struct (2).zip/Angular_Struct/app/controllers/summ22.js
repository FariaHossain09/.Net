app.controller("summ2",function($scope){
    $scope.stCount = 24;
});
